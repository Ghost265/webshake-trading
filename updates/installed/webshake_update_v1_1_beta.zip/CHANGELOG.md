# Webshake Trading v1.1 Beta

Neu:
- KI Analyse 2.0
- RSI, SMA/EMA, Momentum, Trendstärke, Signalqualität
- erweiterter KI-Live-Monitor vorbereitet
- Update-ZIP-Archivierung vorbereitet
- zentrale Versionsdaten über version.json
