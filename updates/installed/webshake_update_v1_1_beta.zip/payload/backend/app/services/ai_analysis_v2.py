from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable, Dict, Any
from .technical_indicators import rsi, ema, sma, momentum, trend_strength

@dataclass
class AiAnalysisV2Result:
    decision: str
    confidence: int
    rsi: float | None
    rsi_status: str
    ema_9: float | None
    ema_21: float | None
    sma_20: float | None
    momentum_10: float | None
    trend_strength: float | None
    signal_quality: str
    explanation: str
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

def _rsi_status(value):
    if value is None: return "UNKNOWN"
    if value >= 70: return "OVERBOUGHT"
    if value <= 30: return "OVERSOLD"
    return "NEUTRAL"

def analyze_prices(prices: Iterable[float]) -> AiAnalysisV2Result:
    data = [float(p) for p in prices if p is not None]
    rsi_value = rsi(data, 14)
    ema_short = ema(data, 9)
    ema_long = ema(data, 21)
    sma_value = sma(data, 20)
    mom = momentum(data, 10)
    strength = trend_strength(data, 9, 21)
    score = 0
    reasons = []
    rs = _rsi_status(rsi_value)
    if rs == "OVERSOLD":
        score += 2; reasons.append("RSI zeigt überverkauften Bereich.")
    elif rs == "OVERBOUGHT":
        score -= 2; reasons.append("RSI zeigt überkauften Bereich.")
    elif rs == "NEUTRAL":
        reasons.append("RSI ist neutral.")
    if ema_short is not None and ema_long is not None:
        if ema_short > ema_long:
            score += 2; reasons.append("EMA 9 liegt über EMA 21.")
        elif ema_short < ema_long:
            score -= 2; reasons.append("EMA 9 liegt unter EMA 21.")
    if mom is not None:
        if mom > 0:
            score += 1; reasons.append("Momentum ist positiv.")
        elif mom < 0:
            score -= 1; reasons.append("Momentum ist negativ.")
    if strength is not None:
        if strength > 0.03:
            score += 1; reasons.append("Trendstärke positiv.")
        elif strength < -0.03:
            score -= 1; reasons.append("Trendstärke negativ.")
    decision = "BUY" if score >= 3 else "SELL" if score <= -3 else "HOLD"
    confidence = min(95, max(45, 50 + abs(score) * 8))
    quality = "HIGH" if abs(score) >= 4 else "MEDIUM" if abs(score) >= 2 else "LOW"
    return AiAnalysisV2Result(decision, confidence, rsi_value, rs,
        round(ema_short, 2) if ema_short else None,
        round(ema_long, 2) if ema_long else None,
        round(sma_value, 2) if sma_value else None,
        mom, strength, quality,
        " ".join(reasons) if reasons else "Noch nicht genug Daten für eine belastbare Analyse.")
