@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Webshake Trading v1.1 Beta Update
echo.
python scripts\apply_update_v1_1.py
echo.
echo Update abgeschlossen. Taste drücken zum Schließen.
pause >nul
