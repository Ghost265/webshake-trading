@echo off
setlocal
cd /d "%~dp0"
echo.
echo Webshake Trading Update
echo -----------------------
python scripts\update_engine.py
set EXITCODE=%ERRORLEVEL%
echo.
if "%EXITCODE%"=="0" (
  echo Update abgeschlossen.
  echo Webshake Trading wird automatisch gestartet...
  timeout /t 3 >nul
  start "" "%~dp0start_webshake.bat"
) else (
  echo Update mit Fehler beendet. Fehlercode: %EXITCODE%
  pause
)
exit /b %EXITCODE%
