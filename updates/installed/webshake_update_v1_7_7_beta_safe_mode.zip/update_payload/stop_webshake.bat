@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\kill_webshake_python.ps1"
pause
