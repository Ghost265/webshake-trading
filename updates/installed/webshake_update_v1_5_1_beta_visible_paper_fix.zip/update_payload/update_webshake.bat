@echo off
setlocal
cd /d "%~dp0"
python scripts\update_engine.py
set EXITCODE=%ERRORLEVEL%
echo.
if "%EXITCODE%"=="0" (
  echo Update abgeschlossen.
) else (
  echo Update mit Fehler beendet. Fehlercode: %EXITCODE%
)
echo.
pause
exit /b %EXITCODE%
