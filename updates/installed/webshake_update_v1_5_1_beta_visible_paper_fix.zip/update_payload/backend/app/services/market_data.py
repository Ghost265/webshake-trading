from datetime import datetime
from statistics import mean
import time
import httpx


class MarketDataService:
    """Coinbase-Marktdaten mit Cache, echtem 24H High/Low und sicherem Fallback."""

    def __init__(self) -> None:
        self.last_price = 95000.0
        self.history: list[float] = []
        self.last_source = "starting"
        self.last_tick: dict | None = None
        self.last_stats: dict | None = None
        self.last_fetch_monotonic = 0.0
        self.last_stats_fetch_monotonic = 0.0
        self.min_fetch_interval_seconds = 0.35
        self.min_stats_interval_seconds = 15.0

    def _remember(self, price: float) -> None:
        self.last_price = float(price)
        self.history.append(float(price))
        self.history = self.history[-240:]

    def _local_high_low(self, price: float) -> tuple[float, float]:
        prices = self.history[-240:] or [price]
        return round(max(prices), 2), round(min(prices), 2)

    def get_24h_stats(self, force: bool = False) -> dict:
        """Liefert echte 24H-Werte der Coinbase-Stats-API.

        Die Werte sind unabhängig davon, wie lange Webshake Trading bereits läuft.
        Bei Netzwerkproblemen wird der letzte bekannte Wert oder die lokale Laufzeit-Historie genutzt.
        """
        now = time.monotonic()
        if self.last_stats and not force and (now - self.last_stats_fetch_monotonic) < self.min_stats_interval_seconds:
            cached = dict(self.last_stats)
            cached["cached"] = True
            cached["timestamp"] = datetime.now().isoformat(timespec="seconds")
            return cached
        try:
            url = "https://api.exchange.coinbase.com/products/BTC-EUR/stats"
            headers = {"User-Agent": "Webshake-Trading-v1.0.1"}
            with httpx.Client(timeout=7.0, headers=headers) as client:
                response = client.get(url)
                response.raise_for_status()
                data = response.json()
            high = float(data.get("high") or 0)
            low = float(data.get("low") or 0)
            open_price = float(data.get("open") or 0)
            volume = float(data.get("volume") or 0)
            if high <= 0 or low <= 0:
                high, low = self._local_high_low(self.last_price)
                source = "local-runtime-fallback"
            else:
                source = "coinbase-24h-stats"
            stats = {
                "symbol": "BTC-EUR",
                "period": "24H",
                "high_24h_eur": round(high, 2),
                "low_24h_eur": round(low, 2),
                "open_24h_eur": round(open_price, 2),
                "volume_24h": volume,
                "source": source,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": source != "coinbase-24h-stats",
                "cached": False,
            }
            self.last_stats = stats
            self.last_stats_fetch_monotonic = now
            return stats
        except Exception as exc:
            high, low = self._local_high_low(self.last_price)
            stats = self.last_stats or {
                "symbol": "BTC-EUR",
                "period": "24H",
                "high_24h_eur": high,
                "low_24h_eur": low,
                "open_24h_eur": 0,
                "volume_24h": 0,
                "source": "local-runtime-fallback",
            }
            stats = dict(stats)
            stats.update({
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": True,
                "cached": False,
                "error": str(exc),
            })
            self.last_stats = stats
            self.last_stats_fetch_monotonic = now
            return stats

    def get_btc_eur_price(self) -> dict:
        now = time.monotonic()
        if self.last_tick and (now - self.last_fetch_monotonic) < self.min_fetch_interval_seconds:
            cached = dict(self.last_tick)
            cached["cached"] = True
            cached["timestamp"] = datetime.now().isoformat(timespec="seconds")
            return cached
        try:
            url = "https://api.exchange.coinbase.com/products/BTC-EUR/ticker"
            headers = {"User-Agent": "Webshake-Trading-v1.0.1"}
            with httpx.Client(timeout=7.0, headers=headers) as client:
                response = client.get(url)
                response.raise_for_status()
                data = response.json()
            price = float(data["price"])
            self._remember(price)
            self.last_source = "coinbase-live"
            stats = self.get_24h_stats()
            local_high, local_low = self._local_high_low(price)
            tick = {
                "symbol": "BTC-EUR",
                "price_eur": round(price, 2),
                "bid": float(data.get("bid", 0) or 0),
                "ask": float(data.get("ask", 0) or 0),
                "volume": float(data.get("volume", 0) or 0),
                "high_eur": stats.get("high_24h_eur", local_high),
                "low_eur": stats.get("low_24h_eur", local_low),
                "high_24h_eur": stats.get("high_24h_eur", local_high),
                "low_24h_eur": stats.get("low_24h_eur", local_low),
                "open_24h_eur": stats.get("open_24h_eur", 0),
                "volume_24h": stats.get("volume_24h", 0),
                "high_low_period": "24H",
                "high_low_source": stats.get("source", "unknown"),
                "source": self.last_source,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": False,
                "cached": False,
            }
            self.last_tick = tick
            self.last_fetch_monotonic = now
            return tick
        except Exception as exc:
            self._remember(self.last_price)
            self.last_source = "fallback-last-known"
            stats = self.get_24h_stats()
            local_high, local_low = self._local_high_low(self.last_price)
            tick = {
                "symbol": "BTC-EUR",
                "price_eur": round(self.last_price, 2),
                "bid": 0,
                "ask": 0,
                "volume": 0,
                "high_eur": stats.get("high_24h_eur", local_high),
                "low_eur": stats.get("low_24h_eur", local_low),
                "high_24h_eur": stats.get("high_24h_eur", local_high),
                "low_24h_eur": stats.get("low_24h_eur", local_low),
                "open_24h_eur": stats.get("open_24h_eur", 0),
                "volume_24h": stats.get("volume_24h", 0),
                "high_low_period": "24H",
                "high_low_source": stats.get("source", "local-runtime-fallback"),
                "source": self.last_source,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": True,
                "cached": False,
                "error": str(exc),
            }
            self.last_tick = tick
            self.last_fetch_monotonic = now
            return tick

    def indicators(self) -> dict:
        prices = self.history[-60:]
        if not prices:
            self.get_btc_eur_price()
            prices = self.history[-60:]
        last = prices[-1] if prices else self.last_price
        sma_short = mean(prices[-5:]) if len(prices) >= 5 else last
        sma_long = mean(prices[-20:]) if len(prices) >= 20 else mean(prices) if prices else last
        change_5 = ((last - prices[-5]) / prices[-5] * 100) if len(prices) >= 5 and prices[-5] else 0
        volatility = (max(prices[-20:]) - min(prices[-20:])) / last * 100 if len(prices) >= 20 and last else 0
        if abs(sma_short - sma_long) < max(0.01, last * 0.00001):
            trend = "FLAT"
        else:
            trend = "UP" if sma_short > sma_long else "DOWN"
        stats = self.get_24h_stats()
        local_high, local_low = self._local_high_low(last)
        return {
            "samples": len(self.history),
            "sma_short": round(sma_short, 2),
            "sma_long": round(sma_long, 2),
            "change_5_samples_pct": round(change_5, 4),
            "volatility_20_samples_pct": round(volatility, 4),
            "trend": trend,
            "high_eur": stats.get("high_24h_eur", local_high),
            "low_eur": stats.get("low_24h_eur", local_low),
            "high_24h_eur": stats.get("high_24h_eur", local_high),
            "low_24h_eur": stats.get("low_24h_eur", local_low),
            "high_low_period": "24H",
            "high_low_source": stats.get("source", "unknown"),
        }


market_data = MarketDataService()
