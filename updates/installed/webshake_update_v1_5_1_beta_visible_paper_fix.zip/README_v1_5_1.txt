Webshake Trading v1.5.1 Beta

ZIP in updates legen und update_webshake.bat starten.
