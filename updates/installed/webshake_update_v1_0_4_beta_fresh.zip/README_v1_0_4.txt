Webshake Trading v1.0.4 Beta

Installation mit neuer Update-Engine:
1. Diese ZIP-Datei NICHT entpacken.
2. ZIP-Datei in den Ordner updates legen.
3. update_webshake.bat starten.

Falls die neue Update-Engine noch nicht installiert ist:
- Erst v1.0.3 Update-Engine installieren.
