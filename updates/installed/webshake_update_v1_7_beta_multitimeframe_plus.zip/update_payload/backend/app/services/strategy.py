from app.services.market_data import market_data


class StrategyEngine:
    """v1.7: Multi-Timeframe KI-Analyse für Paper-Trading.

    Die KI kombiniert kurzfristige und längere Zeiträume. Paper-Trades werden
    nur empfohlen, wenn mehrere Zeiträume zusammenpassen.
    """

    def _decision_from_timeframes(self, timeframes: dict) -> dict:
        frames = timeframes.get("timeframes", {}) if isinstance(timeframes, dict) else {}
        weights = {
            "1M": 0.10,
            "5M": 0.18,
            "15M": 0.22,
            "1H": 0.22,
            "4H": 0.18,
            "24H": 0.10,
        }

        buy_score = 0.0
        sell_score = 0.0
        hold_score = 0.0
        ready_count = 0
        reasons = []

        for label, weight in weights.items():
            data = frames.get(label, {}) or {}
            trend = str(data.get("trend", "UNKNOWN")).upper()
            if not data.get("ready"):
                hold_score += weight * 0.8
                reasons.append(f"{label}: noch nicht genug Daten")
                continue

            ready_count += 1
            momentum = float(data.get("momentum_pct", 0) or 0)
            volatility = float(data.get("volatility_pct", 0) or 0)

            if trend == "UP":
                buy_score += weight
                reasons.append(f"{label}: UP ({momentum:.2f} %)")
            elif trend == "DOWN":
                sell_score += weight
                reasons.append(f"{label}: DOWN ({momentum:.2f} %)")
            else:
                hold_score += weight
                reasons.append(f"{label}: FLAT")

            # Sehr starke Schwankungen erhöhen HOLD leicht, damit Paper-Trading vorsichtiger bleibt.
            if volatility > 2.5:
                hold_score += weight * 0.25

        total = buy_score + sell_score + hold_score
        if total <= 0:
            buy_pct = sell_pct = 0
            hold_pct = 100
        else:
            buy_pct = round((buy_score / total) * 100, 1)
            sell_pct = round((sell_score / total) * 100, 1)
            hold_pct = round(max(0, 100 - buy_pct - sell_pct), 1)

        if ready_count < 3:
            action = "HOLD"
            confidence = 0.42
            decision_reason = "Multi-Timeframe sammelt noch historische Daten. Mindestens 3 auswertbare Zeiträume nötig."
        elif buy_pct >= 58 and buy_pct >= sell_pct + 18:
            action = "BUY"
            confidence = min(0.92, buy_pct / 100)
            decision_reason = "Mehrere Zeiträume zeigen gemeinsam Aufwärtsdruck."
        elif sell_pct >= 55 and sell_pct >= buy_pct + 15:
            action = "SELL"
            confidence = min(0.90, sell_pct / 100)
            decision_reason = "Mehrere Zeiträume zeigen gemeinsam Abwärtsdruck."
        else:
            action = "HOLD"
            confidence = max(0.50, hold_pct / 100)
            decision_reason = "Keine klare Mehrheitslage. KI wartet auf ein saubereres Signal."

        return {
            "action": action,
            "confidence": round(float(confidence), 2),
            "probabilities": {
                "BUY": buy_pct,
                "SELL": sell_pct,
                "HOLD": hold_pct,
            },
            "ready_count": ready_count,
            "reason": decision_reason,
            "details": reasons,
        }

    def analyze(self) -> dict:
        tick = market_data.get_btc_eur_price()
        indicators = market_data.indicators()
        timeframes = market_data.get_timeframes()

        decision = self._decision_from_timeframes(timeframes)

        return {
            "tick": tick,
            "indicators": indicators,
            "timeframes": timeframes,
            "probabilities": decision["probabilities"],
            "action": decision["action"],
            "confidence": decision["confidence"],
            "reason": decision["reason"],
            "decision_details": decision["details"],
            "strategy": "multi-timeframe-v1.7",
        }


strategy_engine = StrategyEngine()
