@echo off
setlocal
cd /d "%~dp0"
python scripts\apply_update_v1_4_full.py
echo.
pause
