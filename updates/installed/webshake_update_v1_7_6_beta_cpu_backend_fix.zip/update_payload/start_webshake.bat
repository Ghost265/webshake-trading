@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\start_webshake.ps1"
if errorlevel 1 (
  echo.
  echo Start mit Fehler beendet. Bitte logs\backend_start.log und logs\frontend_start.log prüfen.
  pause
)
