$ErrorActionPreference = "Continue"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$configPath = Join-Path $root "config\webshake_config.json"
$config = @{ backend_host="127.0.0.1"; backend_port=8765; frontend_host="127.0.0.1"; frontend_port=5173; show_console_windows=$false }

if (Test-Path $configPath) {
  try {
    $json = Get-Content $configPath -Raw | ConvertFrom-Json
    $config.backend_host=$json.backend_host
    $config.backend_port=$json.backend_port
    $config.frontend_host=$json.frontend_host
    $config.frontend_port=$json.frontend_port
    $config.show_console_windows=[bool]$json.show_console_windows
  } catch {}
}

$backendUrl = "http://$($config.backend_host):$($config.backend_port)/api/status"
$frontendUrl = "http://$($config.frontend_host):$($config.frontend_port)/"
$logDir = Join-Path $root "logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

function Test-Url($url, $tries, $sleepMs) {
  for($i=0; $i -lt $tries; $i++) {
    try {
      $r = Invoke-WebRequest -UseBasicParsing $url -TimeoutSec 1
      if($r.StatusCode -ge 200) { return $true }
    } catch {}
    Start-Sleep -Milliseconds $sleepMs
  }
  return $false
}

function Stop-Port($port) {
  try {
    Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue |
    ForEach-Object { if($_.OwningProcess){ Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } }
  } catch {}
}

function Start-HiddenCmd($title, $workdir, $cmd, $logFile) {
  $windowStyle = if($config.show_console_windows) { "Normal" } else { "Hidden" }
  $arg = "/c title $title && cd /d `"$workdir`" && $cmd > `"$logFile`" 2>&1"
  Start-Process -FilePath "cmd.exe" -ArgumentList $arg -WorkingDirectory $workdir -WindowStyle $windowStyle | Out-Null
}

Write-Host "Starte Webshake Trading v1.7.6..."

if (-not (Test-Path (Join-Path $root "backend"))) { Write-Host "FEHLER: backend-Ordner fehlt."; exit 1 }
if (-not (Test-Path (Join-Path $root "desktop"))) { Write-Host "FEHLER: desktop-Ordner fehlt."; exit 1 }

# Alte hängende Prozesse entfernen, damit Backend sauber neu bindet.
Stop-Port $config.backend_port
Stop-Port $config.frontend_port
Start-Sleep -Seconds 1

$backend = Join-Path $root "backend"
$desktop = Join-Path $root "desktop"

if (-not (Test-Path (Join-Path $backend ".venv\Scripts\python.exe"))) {
  Write-Host "Erstelle Python-Umgebung..."
  Push-Location $backend
  python -m venv .venv
  Pop-Location
}

$py = Join-Path $backend ".venv\Scripts\python.exe"
$pip = Join-Path $backend ".venv\Scripts\pip.exe"

if (Test-Path (Join-Path $backend "requirements.txt")) {
  Write-Host "Pruefe Backend-Abhaengigkeiten..."
  Start-Process -FilePath $pip -ArgumentList "install -r requirements.txt" -WorkingDirectory $backend -Wait -WindowStyle Hidden | Out-Null
}

if (-not (Test-Url $backendUrl 2 250)) {
  Write-Host "Starte Backend..."
  Start-HiddenCmd "Webshake Backend" $backend "`"$py`" -m uvicorn app.main:app --host 127.0.0.1 --port $($config.backend_port)" (Join-Path $logDir "backend_start.log")
}

if (-not (Test-Url $backendUrl 30 500)) {
  Write-Host "FEHLER: Backend ist nicht erreichbar."
  Write-Host "Pruefe logs\backend_start.log"
  exit 2
}

if (-not (Test-Path (Join-Path $desktop "node_modules"))) {
  Write-Host "Installiere Frontend-Abhaengigkeiten..."
  Start-HiddenCmd "Webshake NPM Install" $desktop "npm install" (Join-Path $logDir "npm_install.log")
  Start-Sleep -Seconds 8
}

if (-not (Test-Url $frontendUrl 2 250)) {
  Write-Host "Starte Frontend..."
  Start-HiddenCmd "Webshake Frontend" $desktop "npm run dev -- --host 127.0.0.1 --port $($config.frontend_port)" (Join-Path $logDir "frontend_start.log")
}

if (-not (Test-Url $frontendUrl 40 500)) {
  Write-Host "FEHLER: Frontend ist nicht erreichbar."
  Write-Host "Pruefe logs\frontend_start.log"
  exit 3
}

Write-Host "Starte Oberflaeche..."
Start-Process -FilePath "cmd.exe" -ArgumentList "/c cd /d `"$desktop`" && npm start > `"$logDir\electron_start.log`" 2>&1" -WorkingDirectory $desktop -WindowStyle Hidden | Out-Null

Write-Host "Webshake Trading wurde gestartet."
exit 0
