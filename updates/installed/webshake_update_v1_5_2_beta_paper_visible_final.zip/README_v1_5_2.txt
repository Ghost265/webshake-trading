Webshake Trading v1.5.2 Beta

Installation:
1. Diese ZIP in den Ordner updates legen
2. alte ZIPs dort loeschen
3. update_webshake.bat starten

Wichtig:
- Nur Paper-Trading, keine echten Coinbase-Orders.
- Versionsanzeige/Changelog werden ueber Backend/API synchronisiert.
