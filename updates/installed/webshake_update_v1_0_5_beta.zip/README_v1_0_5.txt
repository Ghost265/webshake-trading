Webshake Trading v1.0.5 Beta

Installation:
1. Diese ZIP-Datei NICHT entpacken.
2. ZIP-Datei in den Ordner updates legen.
3. update_webshake.bat starten.

Wichtig:
- Alte Update-ZIPs im updates-Ordner am besten vorher entfernen.
- Nach erfolgreicher Installation verschiebt die Update-Engine dieses Paket nach updates/installed.
