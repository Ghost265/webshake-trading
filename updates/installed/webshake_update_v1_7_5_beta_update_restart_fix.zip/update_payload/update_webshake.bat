@echo off
setlocal
cd /d "%~dp0"
echo.
echo Webshake Trading Update
echo -----------------------
echo Laufende Webshake-Prozesse werden vor der Installation sauber beendet.
echo.
python scripts\update_engine.py
set EXITCODE=%ERRORLEVEL%
echo.
if "%EXITCODE%"=="0" (
  echo Update abgeschlossen.
  echo Bitte danach start_webshake.bat starten.
) else (
  echo Update mit Fehler beendet. Fehlercode: %EXITCODE%
)
echo.
pause
exit /b %EXITCODE%
