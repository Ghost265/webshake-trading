from datetime import datetime
from statistics import mean
import time
import httpx


class MarketDataService:
    """Coinbase-Marktdaten mit Cache, echtem 24H High/Low und Multi-Timeframe-Analyse."""

    def __init__(self) -> None:
        self.last_price = 95000.0
        self.history: list[float] = []
        self.timed_history: list[tuple[float, float]] = []
        self.last_source = "starting"
        self.last_tick: dict | None = None
        self.last_stats: dict | None = None
        self.last_fetch_monotonic = 0.0
        self.last_stats_fetch_monotonic = 0.0
        self.last_timeframes: dict | None = None
        self.last_timeframes_fetch_monotonic = 0.0
        self.min_fetch_interval_seconds = 0.35
        self.min_stats_interval_seconds = 15.0
        self.min_timeframe_interval_seconds = 20.0

    def _remember(self, price: float) -> None:
        now = time.time()
        self.last_price = float(price)
        self.history.append(float(price))
        self.history = self.history[-2000:]
        self.timed_history.append((now, float(price)))
        # 24h lokale Historie behalten
        cutoff = now - 24 * 60 * 60
        self.timed_history = [(ts, p) for ts, p in self.timed_history if ts >= cutoff][-5000:]

    def _local_high_low(self, price: float) -> tuple[float, float]:
        prices = [p for _, p in self.timed_history] or self.history[-240:] or [price]
        return round(max(prices), 2), round(min(prices), 2)

    def _analyse_prices(self, prices: list[float], label: str, source: str) -> dict:
        if not prices:
            prices = [self.last_price]
        last = float(prices[-1])
        first = float(prices[0]) if prices else last
        if len(prices) >= 10:
            short = mean(prices[-3:])
            long = mean(prices[-10:])
        elif len(prices) >= 3:
            short = mean(prices[-2:])
            long = mean(prices)
        else:
            short = last
            long = first
        momentum = ((last - first) / first * 100) if first else 0.0
        volatility = ((max(prices) - min(prices)) / last * 100) if last and len(prices) > 1 else 0.0
        threshold = max(0.01, last * 0.00001)
        if abs(short - long) < threshold:
            trend = "FLAT"
        else:
            trend = "UP" if short > long else "DOWN"
        if momentum > 0.05 and trend != "DOWN":
            bias = "bullish"
        elif momentum < -0.05 and trend != "UP":
            bias = "bearish"
        else:
            bias = "neutral"
        return {
            "label": label,
            "samples": len(prices),
            "first_price_eur": round(first, 2),
            "last_price_eur": round(last, 2),
            "trend": trend,
            "bias": bias,
            "momentum_pct": round(momentum, 4),
            "volatility_pct": round(volatility, 4),
            "source": source,
            "ready": len(prices) >= 3,
        }

    def _local_timeframe_prices(self, seconds: int) -> list[float]:
        now = time.time()
        cutoff = now - seconds
        return [p for ts, p in self.timed_history if ts >= cutoff]

    def _coinbase_candles(self, granularity: int, limit: int = 60) -> list[float]:
        url = f"https://api.exchange.coinbase.com/products/BTC-EUR/candles?granularity={granularity}"
        headers = {"User-Agent": "Webshake-Trading-v1.6"}
        with httpx.Client(timeout=8.0, headers=headers) as client:
            response = client.get(url)
            response.raise_for_status()
            data = response.json()
        # Coinbase: [time, low, high, open, close, volume], newest first
        candles = sorted(data[:limit], key=lambda c: c[0])
        return [float(c[4]) for c in candles if len(c) >= 5]

    def get_timeframe_analysis(self, force: bool = False) -> dict:
        now = time.monotonic()
        if self.last_timeframes and not force and (now - self.last_timeframes_fetch_monotonic) < self.min_timeframe_interval_seconds:
            cached = dict(self.last_timeframes)
            cached["cached"] = True
            cached["timestamp"] = datetime.now().isoformat(timespec="seconds")
            return cached

        definitions = [
            ("1M", 60, 60, 30),
            ("5M", 300, 300, 30),
            ("15M", 900, 900, 40),
            ("1H", 3600, 3600, 48),
            ("4H", 14400, 21600, 40),
            ("24H", 86400, 86400, 30),
        ]
        result = {}
        errors = []
        for label, seconds, granularity, limit in definitions:
            prices: list[float] = []
            source = "coinbase-candles"
            try:
                prices = self._coinbase_candles(granularity, limit=limit)
            except Exception as exc:
                errors.append(f"{label}: {exc}")
                source = "local-runtime-fallback"
                prices = self._local_timeframe_prices(seconds)
                if not prices:
                    prices = self.history[-min(len(self.history), 60):] or [self.last_price]
            result[label] = self._analyse_prices(prices, label, source)

        bullish = sum(1 for v in result.values() if v.get("bias") == "bullish")
        bearish = sum(1 for v in result.values() if v.get("bias") == "bearish")
        neutral = len(result) - bullish - bearish
        if bullish >= 3 and bullish > bearish:
            overall = "UP"
            recommendation = "BUY_ALLOWED"
        elif bearish >= 3 and bearish > bullish:
            overall = "DOWN"
            recommendation = "SELL_ALLOWED"
        else:
            overall = "FLAT"
            recommendation = "WAIT"
        payload = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "symbol": "BTC-EUR",
            "timeframes": result,
            "summary": {
                "overall_trend": overall,
                "bullish_count": bullish,
                "bearish_count": bearish,
                "neutral_count": neutral,
                "recommendation": recommendation,
                "rule": "Paper-Trading wird nur bevorzugt, wenn mindestens 3 Zeitraeume zusammenpassen.",
            },
            "errors": errors[-5:],
            "cached": False,
        }
        self.last_timeframes = payload
        self.last_timeframes_fetch_monotonic = now
        return payload

    def get_24h_stats(self, force: bool = False) -> dict:
        now = time.monotonic()
        if self.last_stats and not force and (now - self.last_stats_fetch_monotonic) < self.min_stats_interval_seconds:
            cached = dict(self.last_stats)
            cached["cached"] = True
            cached["timestamp"] = datetime.now().isoformat(timespec="seconds")
            return cached
        try:
            url = "https://api.exchange.coinbase.com/products/BTC-EUR/stats"
            headers = {"User-Agent": "Webshake-Trading-v1.6"}
            with httpx.Client(timeout=7.0, headers=headers) as client:
                response = client.get(url)
                response.raise_for_status()
                data = response.json()
            high = float(data.get("high") or 0)
            low = float(data.get("low") or 0)
            open_price = float(data.get("open") or 0)
            volume = float(data.get("volume") or 0)
            if high <= 0 or low <= 0:
                high, low = self._local_high_low(self.last_price)
                source = "local-runtime-fallback"
            else:
                source = "coinbase-24h-stats"
            stats = {
                "symbol": "BTC-EUR",
                "period": "24H",
                "high_24h_eur": round(high, 2),
                "low_24h_eur": round(low, 2),
                "open_24h_eur": round(open_price, 2),
                "volume_24h": volume,
                "source": source,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": source != "coinbase-24h-stats",
                "cached": False,
            }
            self.last_stats = stats
            self.last_stats_fetch_monotonic = now
            return stats
        except Exception as exc:
            high, low = self._local_high_low(self.last_price)
            stats = self.last_stats or {
                "symbol": "BTC-EUR",
                "period": "24H",
                "high_24h_eur": high,
                "low_24h_eur": low,
                "open_24h_eur": 0,
                "volume_24h": 0,
                "source": "local-runtime-fallback",
            }
            stats = dict(stats)
            stats.update({
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": True,
                "cached": False,
                "error": str(exc),
            })
            self.last_stats = stats
            self.last_stats_fetch_monotonic = now
            return stats

    def get_btc_eur_price(self) -> dict:
        now = time.monotonic()
        if self.last_tick and (now - self.last_fetch_monotonic) < self.min_fetch_interval_seconds:
            cached = dict(self.last_tick)
            cached["cached"] = True
            cached["timestamp"] = datetime.now().isoformat(timespec="seconds")
            return cached
        try:
            url = "https://api.exchange.coinbase.com/products/BTC-EUR/ticker"
            headers = {"User-Agent": "Webshake-Trading-v1.6"}
            with httpx.Client(timeout=7.0, headers=headers) as client:
                response = client.get(url)
                response.raise_for_status()
                data = response.json()
            price = float(data["price"])
            self._remember(price)
            self.last_source = "coinbase-live"
            stats = self.get_24h_stats()
            local_high, local_low = self._local_high_low(price)
            tick = {
                "symbol": "BTC-EUR",
                "price_eur": round(price, 2),
                "bid": float(data.get("bid", 0) or 0),
                "ask": float(data.get("ask", 0) or 0),
                "volume": float(data.get("volume", 0) or 0),
                "high_eur": stats.get("high_24h_eur", local_high),
                "low_eur": stats.get("low_24h_eur", local_low),
                "high_24h_eur": stats.get("high_24h_eur", local_high),
                "low_24h_eur": stats.get("low_24h_eur", local_low),
                "open_24h_eur": stats.get("open_24h_eur", 0),
                "volume_24h": stats.get("volume_24h", 0),
                "high_low_period": "24H",
                "high_low_source": stats.get("source", "unknown"),
                "source": self.last_source,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": False,
                "cached": False,
            }
            self.last_tick = tick
            self.last_fetch_monotonic = now
            return tick
        except Exception as exc:
            self._remember(self.last_price)
            self.last_source = "fallback-last-known"
            stats = self.get_24h_stats()
            local_high, local_low = self._local_high_low(self.last_price)
            tick = {
                "symbol": "BTC-EUR",
                "price_eur": round(self.last_price, 2),
                "bid": 0,
                "ask": 0,
                "volume": 0,
                "high_eur": stats.get("high_24h_eur", local_high),
                "low_eur": stats.get("low_24h_eur", local_low),
                "high_24h_eur": stats.get("high_24h_eur", local_high),
                "low_24h_eur": stats.get("low_24h_eur", local_low),
                "open_24h_eur": stats.get("open_24h_eur", 0),
                "volume_24h": stats.get("volume_24h", 0),
                "high_low_period": "24H",
                "high_low_source": stats.get("source", "local-runtime-fallback"),
                "source": self.last_source,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": True,
                "cached": False,
                "error": str(exc),
            }
            self.last_tick = tick
            self.last_fetch_monotonic = now
            return tick

    def indicators(self) -> dict:
        prices = self.history[-60:]
        if not prices:
            self.get_btc_eur_price()
            prices = self.history[-60:]
        last = prices[-1] if prices else self.last_price
        sma_short = mean(prices[-5:]) if len(prices) >= 5 else last
        sma_long = mean(prices[-20:]) if len(prices) >= 20 else mean(prices) if prices else last
        change_5 = ((last - prices[-5]) / prices[-5] * 100) if len(prices) >= 5 and prices[-5] else 0
        volatility = (max(prices[-20:]) - min(prices[-20:])) / last * 100 if len(prices) >= 20 and last else 0
        if abs(sma_short - sma_long) < max(0.01, last * 0.00001):
            trend = "FLAT"
        else:
            trend = "UP" if sma_short > sma_long else "DOWN"
        stats = self.get_24h_stats()
        local_high, local_low = self._local_high_low(last)
        return {
            "samples": len(self.history),
            "sma_short": round(sma_short, 2),
            "sma_long": round(sma_long, 2),
            "change_5_samples_pct": round(change_5, 4),
            "volatility_20_samples_pct": round(volatility, 4),
            "trend": trend,
            "high_eur": stats.get("high_24h_eur", local_high),
            "low_eur": stats.get("low_24h_eur", local_low),
            "high_24h_eur": stats.get("high_24h_eur", local_high),
            "low_24h_eur": stats.get("low_24h_eur", local_low),
            "high_low_period": "24H",
            "high_low_source": stats.get("source", "unknown"),
        }


market_data = MarketDataService()
