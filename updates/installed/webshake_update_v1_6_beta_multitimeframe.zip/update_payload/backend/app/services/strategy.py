from app.services.market_data import market_data


class StrategyEngine:
    """v1.6: Multi-Timeframe-Analyse fuer kontrolliertes Paper-Trading."""

    def analyze(self) -> dict:
        tick = market_data.get_btc_eur_price()
        indicators = market_data.indicators()
        timeframe_data = market_data.get_timeframe_analysis()
        summary = timeframe_data.get("summary", {})
        frames = timeframe_data.get("timeframes", {})

        trend = indicators.get("trend", "FLAT")
        change = indicators.get("change_5_samples_pct", 0)
        volatility = indicators.get("volatility_20_samples_pct", 0)
        fallback = tick.get("fallback", False)
        bullish = int(summary.get("bullish_count", 0) or 0)
        bearish = int(summary.get("bearish_count", 0) or 0)
        neutral = int(summary.get("neutral_count", 0) or 0)
        overall = summary.get("overall_trend", "FLAT")

        action = "HOLD"
        confidence = 0.52
        reason = "Multi-Timeframe-System beobachtet den Markt. Noch kein gemeinsames Signal."

        if fallback:
            action = "HOLD"
            confidence = 0.25
            reason = "Live-Marktdaten nicht verfügbar. Sicherheitsmodus: kein Trade."
        elif indicators.get("samples", 0) < 10:
            action = "HOLD"
            confidence = 0.40
            reason = f"Erst {indicators.get('samples',0)} Live-Datenpunkte gesammelt. Mehr Daten nötig."
        elif bullish >= 3 and bullish > bearish and overall == "UP" and trend != "DOWN":
            action = "BUY"
            confidence = min(0.86, 0.58 + bullish * 0.06 + max(0, change) / 100)
            reason = f"BUY-Signal: {bullish} Zeiträume bullish, kurzfristiger Trend nicht DOWN."
        elif bearish >= 3 and bearish > bullish and overall == "DOWN":
            action = "SELL"
            confidence = min(0.84, 0.58 + bearish * 0.06 + abs(min(0, change)) / 100)
            reason = f"SELL-Signal: {bearish} Zeiträume bearish, Markt kippt abwärts."
        elif volatility >= 1.5:
            action = "HOLD"
            confidence = 0.60
            reason = "Hohe kurzfristige Volatilität. Risk Shield empfiehlt Warten."
        else:
            reason = f"Warten: {bullish} bullish, {bearish} bearish, {neutral} neutral. Mindestens 3 passende Zeiträume nötig."

        return {
            "tick": tick,
            "indicators": indicators,
            "timeframes": frames,
            "timeframe_summary": summary,
            "action": action,
            "confidence": round(float(confidence), 2),
            "reason": reason,
            "strategy": "multi-timeframe-v1.6",
        }


strategy_engine = StrategyEngine()
