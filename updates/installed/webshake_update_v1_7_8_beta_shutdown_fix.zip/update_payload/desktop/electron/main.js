const { app, BrowserWindow, ipcMain } = require('electron');
const { exec, spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const http = require('http');

let mainWindow;
let isQuitting = false;

const ROOT_DIR = path.resolve(__dirname, '..', '..');
const STATE_FILE = path.join(ROOT_DIR, 'userdata', 'window_state.json');

function readWindowState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return null;
    return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  } catch { return null; }
}

function saveWindowState() {
  try {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    const bounds = mainWindow.getBounds();
    const state = { ...bounds, maximized: mainWindow.isMaximized(), saved_at: new Date().toISOString() };
    fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
  } catch {}
}

function createWindow() {
  const state = readWindowState();
  mainWindow = new BrowserWindow({
    width: state?.width || 1280,
    height: state?.height || 760,
    x: state?.x,
    y: state?.y,
    minWidth: 1050,
    minHeight: 650,
    backgroundColor: '#0b2d46',
    title: 'Webshake Trading | v1.7.8 Beta',
    frame: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  if (state?.maximized) mainWindow.maximize();

  mainWindow.loadURL('http://127.0.0.1:5173');

  mainWindow.on('resize', saveWindowState);
  mainWindow.on('move', saveWindowState);
  mainWindow.on('maximize', saveWindowState);
  mainWindow.on('unmaximize', saveWindowState);

  mainWindow.on('close', async (event) => {
    saveWindowState();
    if (!isQuitting) {
      event.preventDefault();
      await gracefulShutdown('window-close');
    }
  });
}

function run(command) {
  try {
    exec(command, { windowsHide: true }, () => {});
  } catch {}
}

function logShutdown(reason = 'normal') {
  return new Promise((resolve) => {
    try {
      const req = http.request({
        hostname: '127.0.0.1',
        port: 8765,
        path: `/api/system/shutdown-log?reason=${encodeURIComponent(reason)}`,
        method: 'POST',
        timeout: 700
      }, () => resolve());
      req.on('error', () => resolve());
      req.on('timeout', () => { req.destroy(); resolve(); });
      req.end();
    } catch { resolve(); }
  });
}

function killWebshakeProcesses() {
  // Ports freigeben
  run('powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -LocalPort 8765 -ErrorAction SilentlyContinue | ForEach-Object { if($_.OwningProcess){ Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } }"');
  run('powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -LocalPort 5173 -ErrorAction SilentlyContinue | ForEach-Object { if($_.OwningProcess){ Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } }"');

  // Prozesse mit Projektpfad beenden
  const rootEscaped = ROOT_DIR.replace(/\\/g, '\\\\');
  run(`powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { ($_.Name -in @('python.exe','pythonw.exe','node.exe')) -and ($_.CommandLine -like '*${rootEscaped}*' -or $_.CommandLine -like '*uvicorn*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"`);

  // Alte Fenstertitel als Zusatznetz
  run('taskkill /F /FI "WINDOWTITLE eq Webshake Backend" /T');
  run('taskkill /F /FI "WINDOWTITLE eq Webshake Frontend" /T');
  run('taskkill /F /FI "WINDOWTITLE eq Webshake Vite" /T');
  run('taskkill /F /FI "WINDOWTITLE eq Webshake Electron" /T');
}

async function gracefulShutdown(reason = 'normal') {
  if (isQuitting) return;
  isQuitting = true;
  saveWindowState();
  await logShutdown(reason);

  killWebshakeProcesses();

  setTimeout(() => {
    try {
      if (mainWindow && !mainWindow.isDestroyed()) mainWindow.destroy();
    } catch {}
    app.quit();
    process.exit(0);
  }, 900);
}

async function updateRestart() {
  saveWindowState();
  await logShutdown('update-restart');
  killWebshakeProcesses();

  const script = path.join(ROOT_DIR, 'update_restart.bat');
  try {
    spawn('cmd.exe', ['/c', script], { cwd: ROOT_DIR, detached: true, stdio: 'ignore', windowsHide: true }).unref();
  } catch (e) {
    exec(`start "Webshake Update-Restart" "${script}"`, { cwd: ROOT_DIR });
  }

  setTimeout(() => {
    try { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.destroy(); } catch {}
    app.quit();
    process.exit(0);
  }, 500);
}

ipcMain.handle('window:minimize', () => mainWindow?.minimize());
ipcMain.handle('window:maximize', () => {
  if (!mainWindow) return;
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
});
ipcMain.handle('window:close', () => gracefulShutdown('window-close-button'));
ipcMain.handle('app:shutdown', () => gracefulShutdown('beenden-button'));
ipcMain.handle('app:updateRestart', () => updateRestart());

app.whenReady().then(createWindow);
app.on('before-quit', () => { isQuitting = true; });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
