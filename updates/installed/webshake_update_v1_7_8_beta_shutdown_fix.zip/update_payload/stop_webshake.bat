@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\stop_webshake.ps1"
echo.
echo Webshake Hintergrundprozesse wurden beendet.
pause
