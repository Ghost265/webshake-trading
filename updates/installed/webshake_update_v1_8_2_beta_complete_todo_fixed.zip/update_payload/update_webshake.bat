@echo off
setlocal
title Webshake Update
cd /d "%~dp0"
echo.
echo Webshake Trading Update
echo -----------------------
python scripts\update_engine.py
set EXITCODE=%ERRORLEVEL%
echo.
if "%EXITCODE%"=="0" (
  echo Update abgeschlossen.
  echo Webshake Trading wird automatisch gestartet...
  timeout /t 3 >nul
  start "" "%~dp0start_webshake.bat"
  exit /b 0
) else (
  echo Update mit Fehler beendet. Fehlercode: %EXITCODE%
  echo.
  pause
  exit /b %EXITCODE%
)
