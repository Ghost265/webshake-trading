@echo off
setlocal
title Webshake Update Restart
cd /d "%~dp0"
call update_webshake.bat
exit /b %ERRORLEVEL%
