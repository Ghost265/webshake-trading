@echo off
setlocal
title Webshake Start
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\start_webshake.ps1"
set EXITCODE=%ERRORLEVEL%
if "%EXITCODE%"=="0" (
  start "" /min cmd /c "timeout /t 75 >nul & powershell -NoProfile -ExecutionPolicy Bypass -File scripts\close_success_cmds.ps1"
  exit /b 0
) else (
  echo.
  echo Start mit Fehler beendet. Fehlercode: %EXITCODE%
  echo Fehlerfenster bleibt sichtbar.
  pause
  exit /b %EXITCODE%
)
