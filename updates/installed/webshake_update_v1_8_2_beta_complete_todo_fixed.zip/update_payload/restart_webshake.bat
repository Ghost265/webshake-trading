@echo off
setlocal
title Webshake Restart
cd /d "%~dp0"
call stop_webshake.bat
timeout /t 3 >nul
call start_webshake.bat
exit /b %ERRORLEVEL%
