from app.services.market_data import market_data


class StrategyEngine:
    """v1.7.2: Paper-Trading Lernmodus mit Multi-Timeframe-Signalen."""

    def _decision_from_timeframes(self, timeframes: dict, indicators: dict) -> dict:
        frames = timeframes.get("timeframes", {}) if isinstance(timeframes, dict) else {}
        weights = {"1M": 0.18, "5M": 0.22, "15M": 0.20, "1H": 0.16, "4H": 0.14, "24H": 0.10}
        buy_score = 0.0
        sell_score = 0.0
        hold_score = 0.0
        ready_count = 0
        reasons = []

        for label, weight in weights.items():
            data = frames.get(label, {}) or {}
            trend = str(data.get("trend", "UNKNOWN")).upper()
            momentum = float(data.get("momentum_pct", 0) or 0)
            volatility = float(data.get("volatility_pct", 0) or 0)
            if data.get("ready"):
                ready_count += 1
            if trend == "UP":
                buy_score += weight
                reasons.append(f"{label}: UP ({momentum:.2f} %)")
            elif trend == "DOWN":
                sell_score += weight
                reasons.append(f"{label}: DOWN ({momentum:.2f} %)")
            elif trend == "FLAT":
                hold_score += weight * 0.80
                if momentum > 0:
                    buy_score += weight * 0.20
                elif momentum < 0:
                    sell_score += weight * 0.20
                reasons.append(f"{label}: FLAT")
            else:
                hold_score += weight
                reasons.append(f"{label}: UNKNOWN")
            if volatility > 2.5:
                hold_score += weight * 0.20

        live_trend = str(indicators.get("trend", "FLAT")).upper()
        live_change = float(indicators.get("change_5_samples_pct", 0) or 0)
        if live_trend == "UP" or live_change > 0.005:
            buy_score += 0.16
            reasons.append(f"LIVE: BUY-Impuls ({live_change:.4f} %)")
        elif live_trend == "DOWN" or live_change < -0.005:
            sell_score += 0.16
            reasons.append(f"LIVE: SELL-Impuls ({live_change:.4f} %)")
        else:
            hold_score += 0.10
            reasons.append("LIVE: neutral")

        total = buy_score + sell_score + hold_score
        if total <= 0:
            buy_pct, sell_pct, hold_pct = 0.0, 0.0, 100.0
        else:
            buy_pct = round((buy_score / total) * 100, 1)
            sell_pct = round((sell_score / total) * 100, 1)
            hold_pct = round(max(0, 100 - buy_pct - sell_pct), 1)

        # Paper-Lernmodus: bewusst niedriger Schwellenwert für simulierte Testtrades.
        if buy_pct >= 42 and buy_pct >= sell_pct:
            action = "BUY"
            confidence = max(0.50, min(0.86, buy_pct / 100))
            decision_reason = "Paper-Lernmodus: BUY-Signal reicht für simulierten Testtrade."
        elif sell_pct >= 42 and sell_pct > buy_pct:
            action = "SELL"
            confidence = max(0.50, min(0.86, sell_pct / 100))
            decision_reason = "Paper-Lernmodus: SELL-Signal reicht für simulierten Testtrade."
        else:
            action = "HOLD"
            confidence = max(0.45, min(0.80, hold_pct / 100))
            decision_reason = "Paper-Lernmodus: Signal noch neutral, KI beobachtet weiter."

        return {
            "action": action,
            "confidence": round(float(confidence), 2),
            "probabilities": {"BUY": buy_pct, "SELL": sell_pct, "HOLD": hold_pct},
            "ready_count": ready_count,
            "reason": decision_reason,
            "details": reasons,
        }

    def analyze(self) -> dict:
        tick = market_data.get_btc_eur_price()
        indicators = market_data.indicators()
        timeframes = market_data.get_timeframes()
        decision = self._decision_from_timeframes(timeframes, indicators)
        return {
            "tick": tick,
            "indicators": indicators,
            "timeframes": timeframes,
            "probabilities": decision["probabilities"],
            "action": decision["action"],
            "confidence": decision["confidence"],
            "reason": decision["reason"],
            "decision_details": decision["details"],
            "strategy": "paper-learning-mtf-v1.7.2",
        }


strategy_engine = StrategyEngine()
