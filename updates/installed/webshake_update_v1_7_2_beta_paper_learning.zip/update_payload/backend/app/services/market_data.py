from datetime import datetime, timedelta, timezone
from statistics import mean
import time
import httpx


class MarketDataService:
    """Coinbase-Marktdaten mit Cache, 24H High/Low und Multi-Timeframe-Fallback."""

    def __init__(self) -> None:
        self.last_price = 95000.0
        self.history: list[float] = []
        self.history_ts: list[tuple[float, float]] = []
        self.last_source = "starting"
        self.last_tick: dict | None = None
        self.last_stats: dict | None = None
        self.last_timeframes: dict | None = None
        self.last_fetch_monotonic = 0.0
        self.last_stats_fetch_monotonic = 0.0
        self.last_timeframe_fetch_monotonic = 0.0
        self.min_fetch_interval_seconds = 0.35
        self.min_stats_interval_seconds = 15.0
        self.min_timeframe_interval_seconds = 10.0
        self.candles: dict[str, list[dict]] = {}

    def _remember(self, price: float) -> None:
        self.last_price = float(price)
        self.history.append(float(price))
        self.history = self.history[-2000:]
        self.history_ts.append((time.time(), float(price)))
        self.history_ts = self.history_ts[-5000:]

    def _local_high_low(self, price: float) -> tuple[float, float]:
        prices = self.history[-240:] or [price]
        return round(max(prices), 2), round(min(prices), 2)

    def _coinbase_headers(self) -> dict:
        return {"User-Agent": "Webshake-Trading-v1.7.2"}

    def get_24h_stats(self, force: bool = False) -> dict:
        now = time.monotonic()
        if self.last_stats and not force and (now - self.last_stats_fetch_monotonic) < self.min_stats_interval_seconds:
            cached = dict(self.last_stats)
            cached["cached"] = True
            cached["timestamp"] = datetime.now().isoformat(timespec="seconds")
            return cached
        try:
            url = "https://api.exchange.coinbase.com/products/BTC-EUR/stats"
            with httpx.Client(timeout=7.0, headers=self._coinbase_headers()) as client:
                response = client.get(url)
                response.raise_for_status()
                data = response.json()
            high = float(data.get("high") or 0)
            low = float(data.get("low") or 0)
            open_price = float(data.get("open") or 0)
            volume = float(data.get("volume") or 0)
            if high <= 0 or low <= 0:
                high, low = self._local_high_low(self.last_price)
                source = "local-runtime-fallback"
            else:
                source = "coinbase-24h-stats"
            stats = {
                "symbol": "BTC-EUR",
                "period": "24H",
                "high_24h_eur": round(high, 2),
                "low_24h_eur": round(low, 2),
                "open_24h_eur": round(open_price, 2),
                "volume_24h": volume,
                "source": source,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": source != "coinbase-24h-stats",
                "cached": False,
            }
            self.last_stats = stats
            self.last_stats_fetch_monotonic = now
            return stats
        except Exception as exc:
            high, low = self._local_high_low(self.last_price)
            stats = self.last_stats or {
                "symbol": "BTC-EUR",
                "period": "24H",
                "high_24h_eur": high,
                "low_24h_eur": low,
                "open_24h_eur": 0,
                "volume_24h": 0,
                "source": "local-runtime-fallback",
            }
            stats = dict(stats)
            stats.update({
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": True,
                "cached": False,
                "error": str(exc),
            })
            self.last_stats = stats
            self.last_stats_fetch_monotonic = now
            return stats

    def get_btc_eur_price(self) -> dict:
        now = time.monotonic()
        if self.last_tick and (now - self.last_fetch_monotonic) < self.min_fetch_interval_seconds:
            cached = dict(self.last_tick)
            cached["cached"] = True
            cached["timestamp"] = datetime.now().isoformat(timespec="seconds")
            return cached
        try:
            url = "https://api.exchange.coinbase.com/products/BTC-EUR/ticker"
            with httpx.Client(timeout=7.0, headers=self._coinbase_headers()) as client:
                response = client.get(url)
                response.raise_for_status()
                data = response.json()
            price = float(data["price"])
            self._remember(price)
            self.last_source = "coinbase-live"
            stats = self.get_24h_stats()
            local_high, local_low = self._local_high_low(price)
            tick = {
                "symbol": "BTC-EUR",
                "price_eur": round(price, 2),
                "bid": float(data.get("bid", 0) or 0),
                "ask": float(data.get("ask", 0) or 0),
                "volume": float(data.get("volume", 0) or 0),
                "high_eur": stats.get("high_24h_eur", local_high),
                "low_eur": stats.get("low_24h_eur", local_low),
                "high_24h_eur": stats.get("high_24h_eur", local_high),
                "low_24h_eur": stats.get("low_24h_eur", local_low),
                "open_24h_eur": stats.get("open_24h_eur", 0),
                "volume_24h": stats.get("volume_24h", 0),
                "high_low_period": "24H",
                "high_low_source": stats.get("source", "unknown"),
                "source": self.last_source,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": False,
                "cached": False,
            }
            self.last_tick = tick
            self.last_fetch_monotonic = now
            return tick
        except Exception as exc:
            self._remember(self.last_price)
            self.last_source = "fallback-last-known"
            stats = self.get_24h_stats()
            local_high, local_low = self._local_high_low(self.last_price)
            tick = {
                "symbol": "BTC-EUR",
                "price_eur": round(self.last_price, 2),
                "bid": 0,
                "ask": 0,
                "volume": 0,
                "high_eur": stats.get("high_24h_eur", local_high),
                "low_eur": stats.get("low_24h_eur", local_low),
                "high_24h_eur": stats.get("high_24h_eur", local_high),
                "low_24h_eur": stats.get("low_24h_eur", local_low),
                "open_24h_eur": stats.get("open_24h_eur", 0),
                "volume_24h": stats.get("volume_24h", 0),
                "high_low_period": "24H",
                "high_low_source": stats.get("source", "local-runtime-fallback"),
                "source": self.last_source,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "fallback": True,
                "cached": False,
                "error": str(exc),
            }
            self.last_tick = tick
            self.last_fetch_monotonic = now
            return tick

    def _fetch_candles(self, granularity: int, hours: int) -> list[dict]:
        end = datetime.now(timezone.utc)
        start = end - timedelta(hours=hours)
        url = "https://api.exchange.coinbase.com/products/BTC-EUR/candles"
        params = {"granularity": granularity, "start": start.isoformat(), "end": end.isoformat()}
        with httpx.Client(timeout=10.0, headers=self._coinbase_headers()) as client:
            response = client.get(url, params=params)
            response.raise_for_status()
            raw = response.json()
        candles = []
        for row in raw:
            try:
                candles.append({
                    "time": int(row[0]),
                    "low": float(row[1]),
                    "high": float(row[2]),
                    "open": float(row[3]),
                    "close": float(row[4]),
                    "volume": float(row[5]),
                    "fallback": False,
                })
            except Exception:
                continue
        candles.sort(key=lambda x: x["time"])
        return candles

    def _fallback_candles_from_runtime(self, label: str, required: int) -> list[dict]:
        now = int(time.time())
        gran = {"1M": 60, "5M": 300, "15M": 900, "1H": 3600, "4H": 14400, "24H": 86400}.get(label, 60)
        prices = [p for _, p in self.history_ts[-max(required, 20):]] or self.history[-max(required, 20):] or [self.last_price]
        stats = self.last_stats or {}
        if label == "24H" and stats.get("open_24h_eur"):
            prices = [float(stats.get("open_24h_eur"))] + prices[-max(required - 1, 1):]
        while len(prices) < required:
            # leichte künstliche Staffelung nur für Analyse-Fallback, nicht als echter Kurs
            base = prices[0] if prices else self.last_price
            prices.insert(0, base * (1 - 0.00005 * len(prices)))
        prices = prices[-max(required, 6):]
        candles = []
        for idx, price in enumerate(prices):
            candles.append({
                "time": now - (len(prices) - idx) * gran,
                "low": float(price),
                "high": float(price),
                "open": float(price),
                "close": float(price),
                "volume": 0.0,
                "fallback": True,
            })
        return candles

    def _ensure_timeframe_history(self, force: bool = False) -> None:
        now = time.monotonic()
        if self.last_timeframes and not force and (now - self.last_timeframe_fetch_monotonic) < self.min_timeframe_interval_seconds:
            return
        plan = {
            "1M": {"granularity": 60, "hours": 5, "required": 3},
            "5M": {"granularity": 300, "hours": 24, "required": 3},
            "15M": {"granularity": 900, "hours": 48, "required": 3},
            "1H": {"granularity": 3600, "hours": 7 * 24, "required": 3},
            "4H": {"granularity": 21600, "hours": 30 * 24, "required": 3},
            "24H": {"granularity": 3600, "hours": 24, "required": 6},
        }
        for label, cfg in plan.items():
            try:
                candles = self._fetch_candles(cfg["granularity"], cfg["hours"])
                if len(candles) < cfg["required"]:
                    candles = self._fallback_candles_from_runtime(label, cfg["required"])
                self.candles[label] = candles
            except Exception:
                self.candles[label] = self._fallback_candles_from_runtime(label, cfg["required"])
        self.last_timeframe_fetch_monotonic = now

    def _analyze_candles(self, label: str, candles: list[dict], required: int = 3) -> dict:
        closes = [float(c["close"]) for c in candles if c.get("close")]
        fallback = any(bool(c.get("fallback")) for c in candles)
        if len(closes) < required:
            return {
                "label": label,
                "trend": "UNKNOWN",
                "momentum_pct": 0.0,
                "volatility_pct": 0.0,
                "samples": len(closes),
                "required_samples": required,
                "ready": False,
                "reason": f"Benötigt {required} Datenpunkte, aktuell {len(closes)}",
            }
        first = closes[0]
        last = closes[-1]
        momentum_pct = ((last - first) / first * 100) if first else 0.0
        volatility_pct = ((max(closes) - min(closes)) / last * 100) if last else 0.0
        if abs(momentum_pct) < 0.03:
            trend = "FLAT"
        else:
            trend = "UP" if momentum_pct > 0 else "DOWN"
        return {
            "label": label,
            "trend": trend,
            "momentum_pct": round(momentum_pct, 4),
            "volatility_pct": round(volatility_pct, 4),
            "samples": len(closes),
            "required_samples": required,
            "ready": True,
            "price_first": round(first, 2),
            "price_last": round(last, 2),
            "volume_avg": 0.0,
            "fallback": fallback,
            "reason": "Coinbase-Historie" if not fallback else "Runtime-Fallback",
        }

    def get_timeframes(self, force: bool = False) -> dict:
        self.get_btc_eur_price()
        self._ensure_timeframe_history(force=force)
        required = {"1M": 3, "5M": 3, "15M": 3, "1H": 3, "4H": 3, "24H": 6}
        result = {"symbol": "BTC-EUR", "timestamp": datetime.now().isoformat(timespec="seconds"), "source": "coinbase-candles-or-runtime-fallback", "timeframes": {}}
        for label in ["1M", "5M", "15M", "1H", "4H", "24H"]:
            candles = self.candles.get(label, [])
            if len(candles) < required[label]:
                candles = self._fallback_candles_from_runtime(label, required[label])
                self.candles[label] = candles
            result["timeframes"][label] = self._analyze_candles(label, candles, required[label])
        ready = [v for v in result["timeframes"].values() if v.get("ready")]
        result["ready_count"] = len(ready)
        result["unknown_count"] = 6 - len(ready)
        self.last_timeframes = result
        return result

    def indicators(self) -> dict:
        prices = self.history[-60:]
        if not prices:
            self.get_btc_eur_price()
            prices = self.history[-60:]
        last = prices[-1] if prices else self.last_price
        sma_short = mean(prices[-5:]) if len(prices) >= 5 else last
        sma_long = mean(prices[-20:]) if len(prices) >= 20 else mean(prices) if prices else last
        change_5 = ((last - prices[-5]) / prices[-5] * 100) if len(prices) >= 5 and prices[-5] else 0
        volatility = (max(prices[-20:]) - min(prices[-20:])) / last * 100 if len(prices) >= 20 and last else 0
        if abs(sma_short - sma_long) < max(0.01, last * 0.00001):
            trend = "FLAT"
        else:
            trend = "UP" if sma_short > sma_long else "DOWN"
        stats = self.get_24h_stats()
        tf = self.get_timeframes()
        local_high, local_low = self._local_high_low(last)
        return {
            "samples": len(self.history),
            "sma_short": round(sma_short, 2),
            "sma_long": round(sma_long, 2),
            "change_5_samples_pct": round(change_5, 4),
            "volatility_20_samples_pct": round(volatility, 4),
            "trend": trend,
            "high_eur": stats.get("high_24h_eur", local_high),
            "low_eur": stats.get("low_24h_eur", local_low),
            "high_24h_eur": stats.get("high_24h_eur", local_high),
            "low_24h_eur": stats.get("low_24h_eur", local_low),
            "high_low_period": "24H",
            "high_low_source": stats.get("source", "unknown"),
            "multi_timeframe": tf,
        }


market_data = MarketDataService()
